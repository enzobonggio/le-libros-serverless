class FetchBooksRequest:
    def __init__(self, category, page_number):
        self.category = category
        self.page_number = page_number
